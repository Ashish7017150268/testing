import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import './navbar.css'; // Import CSS styles

const Navbar = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Function to toggle the dropdown menu

  // Function to toggle the dropdown menu
  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  // Function to close the dropdown menu when clicking outside
  const closeDropdown = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsDropdownOpen(false);
    }
  };

  // Event listener to close dropdown when clicking outside
  useEffect(() => {
    document.addEventListener('mousedown', closeDropdown);
    return () => {
      document.removeEventListener('mousedown', closeDropdown);
    };
  }, []);

  return (
    <nav className="bg-gray-800 fixed top-0 w-full z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0 hidden md:block">
            <Link to="/" className="flex items-center">
              <div className="logo-wrapper">
                <img className="logoround" src="../../public/logo/SNJ Infrastructure Inc.png" alt="Logo" />
              </div>
            </Link>
          </div>


          {/* Navbar links */}
          <div className="hidden md:flex flex-grow justify-end">
            <div className="ml-4 flex items-center space-x-4">
              <Link to="/home" className="nav-link">Home</Link>
              <Link to="/about" className="nav-link">About</Link>
              <Link to="/contact" className="nav-link">Contact</Link>
              <Link to="/renovation" className="nav-link">Renovation</Link>
              <Link to="/property-management" className="nav-link">Property Management</Link>
              <div className="relative" ref={dropdownRef}>
                <button type="button" onClick={toggleDropdown} className="dropdown-btn">Service</button>
                {/* Dropdown menu */}
                {isDropdownOpen && (
                  <div className="dropdown-menu">
                    <Link to="/services" className="dropdown-link">Services</Link>
                    <Link to="/about" className="dropdown-link">About</Link>
                  </div>
                )}
              </div>
            </div>
          </div>
          {/* Mobile menu toggle */}
          <div className="md:hidden flex">
            <button onClick={toggleDropdown} className="mobile-menu-btn">
              <svg className="h-6 w-6 fill-current text-white" viewBox="0 0 24 24">
                <path fillRule="evenodd" clipRule="evenodd" d="M3 6H21V8H3V6ZM3 11H21V13H3V11ZM3 16H21V18H3V16Z"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
      {/* Mobile dropdown menu */}
      {isDropdownOpen && (
        <div className="md:hidden absolute w-full bg-gray-800" ref={dropdownRef}>
          <div className="px-2 pt-2 pb-3 space-y-1">
            <Link to="/construction" className="nav-link">Construction</Link>
            <Link to="/renovation" className="nav-link">Renovation</Link>
            <Link to="/property-management" className="nav-link">Property Management</Link>
            <Link to="/services" className="nav-link">Services</Link>
            <Link to="/about" className="nav-link">About</Link>
          </div>
        </div>
      )}
    </nav>
  );
}

export default Navbar;
