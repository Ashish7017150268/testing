/**
 * Footer component for displaying footer content.
 * This component includes sections for company information, navigation links, and social media links.
 * Props:
 * - none
 * Usage:
 * <Footer />
 */
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <>
      {/* Main page wrapper */}
      
   
      Footer section
      <footer className="footer">
        {/* Top section of the footer */}
        <div className="footer_above">
          <div className="container">
            <div className="row">
              {/* Company information column */}
              <div className="col-lg-4 col-md-6 col-sm-12">
                {/* Widget containing company information and subscription form */}
                <div className="hidden md:block" style={{marginTop:'-50px'}}>

                  <a href="index" className="logo-container logo" >
                    <img src="../../public/logo/SNJ logo with Center position 2.png" alt="House Logo" className="house-logo" />
                  </a>

                  {/* Subscription form for newsletter */}
                  <div className="side_footer_social">
                    {/* List for social media icons */}
                    <ul className="bottom_social">
                      <li className="facebook"><a href="#" className=''><i className="fa-brands fa-facebook-f"></i></a></li>
                      <li className="twitter"><a href="#"><i className="fa-brands fa-x-twitter"></i></a></li>
                      <li className="dribbble"><a href="#"><i className="fa-brands fa-youtube"></i></a></li>
                      <li className="instagram"><a href="#"><i className="fa-brands fa-instagram"></i></a></li>
                      <li className="linkedin"><a href="#"><i className="fa-solid fa-map"></i></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            
              {/* Useful links columns */}
              <div className="col-lg-2 col-md-6 col-sm-12">
                {/* Widget containing useful links */}
                <div className="footer_widget footer_links">
                  {/* Title for the widget */}
                  <h4 className="widget_title">Useful Links</h4>
                  {/* Navigation menu for useful links */}
                  <div className="footer_nav">
                    <ul className="footer_menu">
                      <li className="menu-item"><a  className='textwhite' href="/about">About Us</a></li>
                      <li className="menu-item"><a  className='textwhite' href="/blog-details">Courses</a></li>
                      <li className="menu-item"><a  className='textwhite' href="/project-details">Enrollment</a></li>
                      <li className="menu-item"><a  className='textwhite' href="/service-details">Be an Instructor</a></li>
                      <li className="menu-item"><a  className='textwhite' href="/contact">Contact Us</a></li>
                    </ul>
                  </div>
                </div>
              </div>

                {/* Navigation links columns */}
                <div className="col-lg-2 col-md-6 col-sm-12">
                {/* Widget containing navigation links */}
                <div className="footer_widget footer_links">
                  {/* Title for the widget */}
                  <h4 className="widget_title">Services</h4>
                  {/* Navigation menu for services */}
                  <div className="footer_nav">
                    <ul className="footer_menu">
                    <li className="menu-item text-white"><Link to="/service/Construction" className='textwhite'>Construction </Link></li>
                    <li className="menu-item"><Link className='textwhite' to="/service/Renovation">Renovation </Link></li>
                    <li className="menu-item"><Link className='textwhite' to="/service/Property-Management">Property management</Link></li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Address and social media columns */}
              <div className="col-lg-4 col-md-6 col-sm-12">
                {/* Widget containing address and social media links */}
                <div className="footer_widget">
                  {/* Title for the widget */}
                  <h4 className="widget_title">Address</h4>
                  {/* List for address details */}
                  <ul>
                    {/* Address information */}
                    <li><i className="fa-solid fa-location-dot"></i><span className='textwhite'>13 Madison Street NewYork, USA</span></li>
                    <li><i className="fa fa-envelope" aria-hidden="true"></i><span className='textwhite'>builderrine@gmail.com</span></li>
                    <li><i className="fa fa-clock-o" aria-hidden="true"></i><span className='textwhite'>Monday - Friday (9.00am - 9.00pm)</span></li>
                  </ul>
                  {/* Social media links */}
                  
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Bottom section of the footer */}
        <div className="footer_bottom">
          <div className="container">
            <div className="footer_bottom_inner">

              {/* Copyright information */}
              <div className="copyright font-bold text-white">
                <p className='text-white font-black'>Copyright © 2024 <a  href="/home" className='text-white'>SNJ Infrastructure Inc.</a> All rights reserved.</p>
              </div>
              <div className="totop">
                <a href="#"><i className="fa-solid fa-arrow-up"></i></a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}

export default Footer;
