import './style.css'; // Importing custom styles for the footer
import './personal.css'; // Importing custom styles for the footer
import './navbar.css';
function Header() {
  return (
    <header className="header">
    <div className="top_bar navitem" id="top-bar">
      <div className="flex justify-between items-center mymargin">
        <div className="header_info flex items-center">
          <div className="schedule mr-4 hidden md:block">
            <a href='#'>
            <div className="logo hidden md:block" style={{backgroundImage: `url('../../public/logo/Rectangle 2.png')`, width: '295px', height: '142px'}}>
            <img className="logoround" src="../../public/logo/SNJ logo with Center position 1.png" alt="Logo" style={{marginLeft:'104px'}}/>
            </div>
            </a>
          </div>
          <div className="contact_info flex items-center">
            <div className="schedule mr-4">
              <a href='#'>
                <span><i className="fa fa-envelope"></i></span> <span className='text-white'>example@gmail.com</span>
              </a>
            </div>
            <div className="schedule">
              <a href='#'>
                <span><i className="fa-solid fa-phone-volume"></i></span> <span className='text-white'> +91 1234567876 </span>
              </a>
            </div>
          </div>
        </div>
  
        <div className="bg-yellow hidden md:block">
          <button>Contact Us</button>
        </div>
      </div>
    </div>
    <div className="middle_bar">
      <div className="container mx-auto">
        <div className="middle_bar_inner flex justify-between items-center">
          <div className="header_right_part">
            <div className="mainnav">
              <ul className="main_menu flex">
                <li className="menu-item rightline">
                  <a href="/" >Home</a>
                </li>
                <li className="menu-item menu-item-has-children rightline">
                  <a href="#" className="flex items-center" style={{marginRight: '18px'}}>
                    Services <i className="ion-arrow-right-b ml-2"></i>
                  </a>
                  
                  <ul className="sub-menu">
                    <li className="menu-item">
                      <a href="/services">Service One</a>
                    </li>
                    <li className="menu-item">
                      <a href="/services-2">Service Two</a>
                    </li>
                    <li className="menu-item">
                      <a href="/service-details">Service Details</a>
                    </li>
                  </ul>
                </li>
                <li className="menu-item rightline">
                  <a href="#">About Us</a>
                </li>
                <li className="menu-item rightline">
                  <a href="#">Blog</a>
                </li>
                <li className="menu-item rightline">
                  <a href="/contact">Contact Us</a>
                </li>
              </ul>
            </div>
            <div className="side_footer_social flex items-center ml-4">
              {/* List for social media icons */}
              <ul className="bottom_social flex">
                <li className="facebook"><a href="#" className='bg-lightwhite'><i className="fa-brands fa-facebook-f"></i></a></li>
                <li className="twitter"><a href="#" className='bg-lightwhite'><i className="fa-brands fa-x-twitter"></i></a></li>
                <li className="dribbble"><a href="#"><i className="fa-brands fa-youtube"></i></a></li>
              </ul>
            </div>
            <button className="ma5menu__toggle position-relative d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasHome" aria-controls="offcanvasHome">
              <i className="fa-solid fa-grip-lines"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  </header>
  
  );
}

export default Header;
