import { lazy } from 'react';
import { createBrowserRouter } from "react-router-dom";

// Import Header and Footer components
import Header from '../componets/Header';
import Footer from '../componets/Footer';

// Import your page components
const Testing = lazy(() => import("../pages/test"));

const Layout = ({ children }) => (
  <> {/* Fixed missing closing tag */}
    <Header />
    <main className="page-wrapper">
      {children}
    </main>
    <Footer />
  </>
);

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout><Testing /></Layout>,
  },
]);

export { router };
