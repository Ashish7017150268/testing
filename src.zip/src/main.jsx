import * as React from "react";
import * as ReactDOM from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import './index.css'
import {NextUIProvider} from '@nextui-org/react'
import {router} from './routes/route';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
     <NextUIProvider>
        <RouterProvider router={router} />
    </NextUIProvider>
  </React.StrictMode>,
)
