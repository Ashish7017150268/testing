import {Button} from "@nextui-org/react";

export default function App() {
  return (
    <Button color="primary">
      Button
    </Button>
  );
}
